const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.static('public')); // Serve static files like HTML, CSS, and images

// Routes
app.get('/api/services', (req, res) => {
    // Dummy data for services
    const services = [
        { name: 'Haircuts and Styling', description: 'Get a trendy haircut and styling from our expert stylists.' },
        { name: 'Facials and Skincare', description: 'Revitalize your skin with our facial treatments and skincare routines.' },
        { name: 'Manicures and Pedicures', description: 'Pamper your hands and feet with our manicure and pedicure services.' },
        { name: 'Massage Therapy', description: 'Relax and rejuvenate with our massage therapy sessions.' }
    ];
    res.json(services);
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
