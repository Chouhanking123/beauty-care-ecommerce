<?php
session_start();
include('db.php');
$login = false;
$showError = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gmail = $_POST["username"];
    $password = $_POST["password"];

    // Prevent SQL Injection
    $sql = "SELECT * FROM form WHERE username='$gmail' && password = '$password' ";
    
    $data= mysqli_query($conn , $sql);
    $num = mysqli_num_rows($data);
  
    if ($num == 1) {
       
               
                $_SESSION['username'] = $gmail;
                
                header('location: index.php');
              
            } 
            else {
                $showError = "Incorrect password";
            }
        }
    

?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Beauty Care Login</title>
<link rel="stylesheet" href="login.css">
</head>
<body>
<div class="login-container">
    <h2>Beauty Care Login</h2>
    <form action="index.php">
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <button type="submit">Login</button>
        <p><a href="signup.php">signup Here</a></p>
    </form>
    <p id="error-message" class="error-message"></p>
   

   
</div>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>


</body>
</html>
