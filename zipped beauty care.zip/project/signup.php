<?php
$showAlert = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'db.php';
    $firstName = $_POST['fname'];
    $lname = $_POST['lname'];
    $Gender = $_POST['Gender'];
    $num = $_POST['number'];
    $address = $_POST['address'];
    $gmail = $_POST['username'];
    $password = $_POST['password'];
    $cpassword = $_POST["cpassword"];
    
    $sql = "SELECT * FROM form WHERE username = '$gmail'";
    $data = mysqli_query($con, $sql);
    $numExistRows = mysqli_num_rows($data); 

    if($numExistRows > 0){
        $exists = true;
        $showError = "Username Already Exists";
    } else {
        $exists = false;
        if($cpassword == $password){
           

            $sql = "INSERT INTO form(fname, lname, gender, num, address , username, password, cpassword) VALUES ('$firstName','$lname','$Gender','$num','$address','$gmail','$password' ,'$cpassword')";
            $data = mysqli_query($con, $sql);
            if($data){
                $showAlert = true;
            }
        } else {
            $showError = "Passwords do not match";
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="signup.css">

    <title>Sign Up</title>
</head>
<body>
    <?php 
    if($showAlert){
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> Your account is now created and you can login
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>';
    }
    if($showError){
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Error!</strong> '. $showError.'
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>';
    }
    ?>
   
    <div class ="signup">
        <h1>Sign Up</h1>
        <form method="post">
            <label>First Name</label>
            <input type="text" name="fname" required>
            <label>Last Name</label>
            <input type="text" name="lname" required>
            <label>Gender</label>
            <div class="custom_select">
                <select>
                    <option>select</option>
                    <option>male</option>
                    <option>female</option>
                </select>
            
            </div>
            <label>Contact Address</label>
            <input type="text" name="number" required>
            <label>Address</label>
            <input type="text" name="address" required>
            <label>Email</label>
            <input type="email" name="username" required>
            <label>Password</label>
            <input type="password" name="password" required>
            <label>Confirm Password</label>
            <input type="password" name="cpassword" required>
           
            <input type="submit" value="Submit">
        </form>
        <p>By clicking the sign up button, you agree to our <br>
            <a href="#">Terms and Conditions</a> and <a href="#">Privacy Policy</a>
        </p>
        <p>Already have an account? <a href="login.php">Login Here</a></p>
    </div>
     
    <!-- Bootstrap JS and dependencies e-->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="/signup.js"></script>
</body>

</html>