
function fun(){
   /*"" document.getElementById("login-form").addEventListener("submit"), function(event)
    {
        event.preventDefault();*/
        var email = document.getElementById("username").value;
    var pass = document.getElementById("password").value;
if(email=='chouhanabhinaw@gmail.com'&& pass =="123456"){
alert("success full !")
window.location.assign("index.html")
}
else
{
    alert("wrong entry invalid" )
}

    
    
    
    
    // Dummy validation
    if (username === "admin" && password === "password") {
        // Replace this with actual login logic
        alert("Login successful!");
    } else {
        document.getElementById("error-message").textContent = "Invalid username or password.";
    }
};
