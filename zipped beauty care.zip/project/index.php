<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Beauty Care</title>
  <link rel="stylesheet" href="styles.css">
</head>


<body background="https://st4.depositphotos.com/3813239/41881/i/450/depositphotos_418810850-stock-photo-make-products-close-light-pink.jpg">
  
  <header>
    <h1>Welcome to Beauty Care</h1>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="service.html">Services</a></li>
        <li><a href="#">About Us</a></li>
        <li><a href="contact.html">Contact </a></li>
        <li><a href="product.html">Products </a></li>
      </ul>
    </nav>
  </header>
  <section class="hero">
    <h4><p class="one">Your beauty is our priority</p></h4>
    <p class="two"> Discover our range of services and products tailored just for you.</p>
    
    <p><a href="#" class="btn">Explore</a></p>
  <section class="services">
    <h2>Our Services</h2>
    <div class="service">
      <img src="pic1.jpg" alt="Service 1">
      <h3>Facials</h3>
      <p >Revitalize your skin with our custom facials.</p>
    </div>
    <div class="service">
      <img src="pic2.jpg" alt="Service 2">
      <h3>Manicure & Pedicure</h3>
      <p>Treat yourself to a relaxing manicure and pedicure session.</p>
    </div>
    <!-- Add more service sections as needed -->
  </section>
  <footer>
    <p>&copy; 2024 Beauty Care. All rights reserved.</p>
  </footer>

  <script src="/script.js"></script>
</body>
</html>