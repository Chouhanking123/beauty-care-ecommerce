<?php
$server = "localhost";
$gmail = "root";
$password = "";
$database = "register";

$con= mysqli_connect($server, $gmail, $password, $database);
// if ($conn){
   
//     echo "success";
// }



?>
