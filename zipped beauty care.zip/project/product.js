var cart = [];

function addToCart(productName, price) {
    cart.push({ name: productName, price: price });
    displayCart();
}

function displayCart() {
    var cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';
    var total = 0;
    cart.forEach(function(item) {
        var li = document.createElement('li');
        li.textContent = item.name + ' - $' + item.price.toFixed(2);
        cartItems.appendChild(li);
        total += item.price;
    });
    document.getElementById('cart-total').textContent = '$' + total.toFixed(2);
}

function checkout() {
    // Implement checkout process here (e.g., redirect to payment page)
    alert('Thank you for your purchase!');
    cart = [];
    displayCart();
}

// You can add more products and functionality as needed
